function EE
    %% Inicializa par�metros ex�genos:
    d    = 2;                      % Dimensiones del problema     
    limits = repmat([0 pi], d, 1); % L�mites del espacio de b�squeda
    mu = 100;                      % N�mero de padres
    lambda = 100;                  % N�mero de hijos
    maxk = 40;                     % N�mero de generaciones
    k = 1;                         % Generaci�n actual
    %% Inicializa variables de decisi�n y par�metros de estrategia:
   [x, sigma, alfa] = INICIA(mu, d, limits(:,1)',limits(:,2)');
    %% Eval�a funci�n objetivo y guarda el mejor:
    f=FUNCION(x',d,mu);
    xmin = cell(1,maxk);                  
    fmin = zeros(maxk,1);                  
    [fmin(1), id] = min(f); 
    xmin{1} = x(:,id);                                           
    %% Estrategias Evolutivas:
    while (k < maxk)
       %% Recombinaci�n para generar lambda descendientes:
       [xr,sigmar,alphar] = RECOMB(x,sigma,alfa,d,mu,lambda);
       %% Mutaci�n de los descendientes:
       [xm,sigmam,alpham] = MUTAC(xr,sigmar,alphar,d,lambda);
       %% Eval�a a los descendientes mutados:
       fm=FUNCION(xm',d,mu);  
       %% Selecci�n de los padres para la siguiente generaci�n:
       [x, sigma, alfa, f] = SEL_MAS(x, sigma, alfa, f, xm, sigmam, alpham, fm, mu);
       k = k+1;                    % Siguiente generaci�n
       fmin(k) = f(1,1);
       xmin{k} = x(:,1);
       fprintf('\tGeneraci�n k = %d,  Fitness = %g\n',k,fmin(k));
    end
    fprintf('\tMejor individuo = %d, %d\n',xmin{k});
    plot(fmin)
end