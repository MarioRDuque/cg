function [xk, sigmak, alfak, fk] = SEL_MAS(x, sigma,  alfa, f, xH, sigmaH,alfaH, fH, mu)
    % Crear poblaciones intermedias de tama�o mu+lambda:
    fI = [fH; f]; 
    xI = [xH x]; 
    sigmaI    = [sigmaH sigma];
    alfaI    = [alfaH alfa]; 
    % Ordenar fitness:
    [fk, idx] = sort(fI);      
    % Tomar mu elementos de las poblaciones intermedias:
    fk=fk(1:mu,1);
    xk   = xI(:,idx(1:mu)); 
    sigmak = sigmaI(idx(1:mu));
    alfak = alfaI(idx(1:mu));
end
