function [xm,sigmam,alfam] = MUTAC(x,sigma,alfa,d,lambda)
   tau   = 1/(sqrt(2*sqrt(d)));          
   tau_  = 1/(sqrt(2*d));                
   beta  = 5*pi/180;                    
   for i = 1:lambda
     sid = randn(d); si=randn();
     sigmam{i} = sigma{i}.*exp(tau_*si + tau*(sid));
     sid = rand(d);
     alfam{i} = alfa{i} + beta*triu((sid),1);
     R = eye(d);
     for k = 1:d-1
       for l = k+1:d
          T = eye(d);
          T([k l], [k l]) = [cos(alfam{i}(k,k))  -sin(alfam{i}(k,l))
                             sin(alfam{i}(l,k))   cos(alfam{i}(l,l)) ];
          R = R*T;
        end
     end
     sid=randn(d,1);
     xm(:,i) = x(:,i) + R*sigmam{i}*sid;
   end
end