function f = FUNCION(x, d, N) 
f=[];
% Michalewikz: optimo: -1.8013
for j=1:N
   m = 10;
   s = 0;
   for i = 1:d
       s = s+sin(x(j,i))*(sin(i*x(j,i)^2/pi))^(2*m);
   end
   f(j,1) = -s; 
end
%f=y; ind=i;   %Para poder imprimir, descomentar esta linea
%[f,ind]=sort(y); %Para optimizar, descomentar esta linea