function [x, sigma, alfa] = INICIA(mu,d,l,u)
  %% Poblaci�n de padres:
  x = zeros(d,mu);
  for i=1:mu
     for n=1:d
          x(n,i)=l(1,n)+rand()*(u(1,n)-l(1,n));  
     end
  end
  %% Poblaci�n de covarianzas:
  sigma  = cell(1,mu);
  for i = 1:mu
      sigma{i}=cov(rand(d,d));
  end
  %% Poblaci�n de rotaciones:
  alfa = cell(1,mu);
  for i = 1:mu
     alfa{i} = zeros(d);
     for n = 1:d-1
        for nn= n+1:d
            alfa{i}(n,nn) = 0.5*atan2(2*sigma{i}(n,nn),(sigma{i}(n,n)^2 - sigma{i}(nn,nn)^2));
        end
     end
  end
end