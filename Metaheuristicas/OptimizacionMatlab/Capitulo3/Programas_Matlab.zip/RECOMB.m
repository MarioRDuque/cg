function [xi,sigmai,alphai] = RECOMB(x,sigma,alpha,d,mu,lambda)
%% Recombina variables de decisi�n:
xi=x;
for i = 1:lambda
   r1i = randsample(1:mu,1);
   for n = 1:d
      chi       = rand();
      r2i       = randsample(1:mu,1);
      xi(n,i)  = x(n,r1i)  + chi*(x(n,r2i)  - x(n,r1i));
   end
end
%% Recombina par�metros de estrategia:
sigmai=sigma; alphai=alpha;
for i = 1:mu
   r1i = randsample(1:mu,1);
   for n = 1:d
      for nn = n:d
        chi = rand();
        r2i = randsample(1:mu,1);
        sigmai{i}(n,nn) = sigma{r1i}(n,nn) + chi*(sigma{r2i}(n,nn) - sigma{r1i}(n,nn));
        sigmai{i}(nn,n) = sigmai{i}(n,nn);
        alphai{i} = alpha{r1i} + chi*(alpha{r2i} - alpha{r1i});
      end
   end
end