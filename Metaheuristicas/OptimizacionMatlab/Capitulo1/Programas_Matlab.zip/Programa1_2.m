
%Limpiar memoria
clear all
%Se inicializan variables
AccionA=0;
NoAccionA=0;
%Inicia el proceso iterativo de desicion
for i=1:10000
    %Se genera el numero aleatorio U[0,1]
    rA=rand;
    %Aceptacion probabilistica
    if (rA<=0.7)
        AccionA=AccionA+1;
    else
        NoAccionA=NoAccionA+1;
    end
end