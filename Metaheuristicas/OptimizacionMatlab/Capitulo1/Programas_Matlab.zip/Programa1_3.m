%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejemplo del metodo de Random Walking
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Erik Cuevas, Valent�n Osuna, Diego Oliva y Margarita D�az 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Limpiar memoria
clear all
%Se define la funcion a optimizar
%funstr='-1*(10*exp(-1*(x^2+3*y^2)))';
funstr='3*(1-x).^2.*exp(-(x.^2)-(y+1).^2)-10*(x/5-x.^3-y.^5).*exp(-x.^2-y.^2)-1/3*exp(-(x+1).^2 -y.^2)';
f=vectorize(inline(funstr));
range=[-3 3 -3 3];
%Se dibuja la funcion como referencia
Ndiv=200;
dx=(range(2)-range(1))/Ndiv; dy=(range(4)-range(3))/Ndiv;
[x,y] =meshgrid(range(1):dx:range(2),range(3):dy:range(4));
z=f(x,y);
figure(1);   surfc(x,y,z);
%Se define el maximo numero de iteraciones
Niter=3000;
k=0;
dato=1;
%Generacion del punto inicial
xrange=range(2)-range(1);
yrange=range(4)-range(3);
xn=rand*xrange+range(1);
yn=rand*yrange+range(3);
figure
%Se establece el proceso iterativo de optimizacion
while(k<Niter)
 %Se evalua si la solucion pertenece al espacio de busqueda X
 if ((xn>=range(1))&(xn<=range(2))&(yn>=range(3))&(yn<=range(4)))
  %Si pertenece se evalua
  zn1=f(xn,yn); 
 else
  %Si no se le da un valor muy bajo
     zn1=-1000;
 end
  %Se grafica el punto
  contour(x,y,z,15); hold on;    
  plot(xn,yn,'.','markersize',10,'markerfacecolor','g');
  drawnow;
  hold off;
  %Se calcula la nueva solucion 
  xnc=xn+randn*1;
  ync=yn+randn*1;
  %Se evalua si la solucion pertenece al espacio de busqueda X
  if ((xnc>=range(1))&(xnc<=range(2))&(ync>=range(3))&(ync<=range(4)))
  %Si pertenece se evalua
      zn2=f(xnc,ync); 
  else
     %Si no se le da un valor muy bajo
     zn2=-1000;
 end
   if (zn2>zn1)
      xn=xnc;
      yn=ync;
      elemento1(dato)=xn;
      elemento2(dato)=yn;
      dato=dato+1;
  end
  k=k+1;
  end