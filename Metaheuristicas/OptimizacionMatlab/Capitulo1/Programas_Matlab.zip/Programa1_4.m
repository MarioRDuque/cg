%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejemplo del metodo de Templado simulado
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Erik Cuevas, Valent�n Osuna, Diego Oliva y Margarita D�az 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Limpiar memoria
clear all
%Se define la funcion a optimizar
funstr='3*(1-x).^2.*exp(-(x.^2)-(y+1).^2)-10*(x/5-x.^3-y.^5).*exp(-x.^2-y.^2)-1/3*exp(-(x+1).^2 -y.^2)';
f=vectorize(inline(funstr)); 
range=[-3 3 -3 3];
%Se dibuja la funcion como referencia
Ndiv=50;
dx=(range(2)-range(1))/Ndiv; dy=(range(4)-range(3))/Ndiv;
[x,y] =meshgrid(range(1):dx:range(2),range(3):dy:range(4));
z=f(x,y);
figure(1);   surfc(x,y,z);
%Se define el maximo numero de iteraciones
k=1;
valido=0;
Niter=150;
ind=1;
% Define temperatura inicial
T_init =1.0;
% Define temperatura final
T_fin = 1e-10; 
% Relacion de enfriamiento 
beta=0.95; 
%Generacion del punto inicial
xrange=range(2)-range(1);
yrange=range(4)-range(3);
xn=rand*xrange+range(1);
yn=rand*yrange+range(3);
%Se inicializa la temperatura 
T = T_init; 
%Se establece el proceso iterativo de optimizacion
while (k<Niter) 
%Se grafica el punto
  contour(x,y,z); hold on;    
  plot(xn,yn,'.','markersize',10,'markerfacecolor','g');
  drawnow;
  hold off;
 %Se calcula la calidad del punto x(k)
  E_old = f(xn,yn);
  %Se produce la nueva solucion x(k+1)
  %El ciclo while aplica hasta que el nuevo punto esta dentro de X
 while(valido==0) 
  %El valor de la desviacion estandar se modifica con T
  xnc=xn+randn*2.5*T;
  ync=yn+randn*2.5*T;
  if ((xnc>=range(1))&(xnc<=range(2))&(ync>=range(3))&(ync<=range(4)))
      valido=1;
  end
 end  
  valido=0;
  %Se obtiene informacion de la evolucion de la temperatura
  data(k)=T;
  %Se calcula la calidad de la nueva solucion
  E_new=f(xnc,ync); 
 %Se calcula la diferencia  
 DeltaE=E_new-E_old;
 % Si la solucion nueva es mejor en calidad que la anterior se acepta
if (DeltaE>0)
   xn=xnc;
    yn=ync;
    info1(ind)=xn;
    info2(ind)=yn;
end
% Si no se analiza probabilisticamente su aceptacion
if (DeltaE<0 & exp(DeltaE/T)>rand ); 
    xn=xnc;
    yn=ync;
    info1(ind)=xn;
    info2(ind)=yn;
end
% Se actualiza la temperatura
T = beta*T; 
if (T<T_fin)
    T=T_fin;
end
k=k+1;
ind=ind+1;
end
