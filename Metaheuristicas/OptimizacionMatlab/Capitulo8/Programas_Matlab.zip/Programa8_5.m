%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Movimiento de part�culas,
%Algoritmo EMO Est�ndar, propuesto por Birbil y Fang [1]
%Prueba con funci�n de Rosenbrock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Erik Cuevas, Valent�n Osuna-Enciso, Diego Oliva, Margarita D�az
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x,fx] = move(F,x,m,n,ind,l,u)
for i=1:m
  if i ~= ind
      for k=1:n
          %Se obtiene un numero aleatorio lambda
          lambda = random('Unif',0,1);
          %Se normaliza el vector de fuerza para la part�cula i
          F(k,i) = F(k,i)/(abs(F(k,i))+eps);
          %Se calcula la nueva posici�n y se desplaza la part�cula i
          if F(k,i)>0
              x(k,i) = x(k,i)+lambda*F(k,i)*(u(k)-x(k,i));
          else
              x(k,i) = x(k,i)+lambda*F(k,i)*(x(k,i)-l(k));
          end
      end
      %Verifica que la nueva posici�n en k no se salga de los limites
      if x(k,i) > u(k)
          x(k,i) = u(k);
      elseif x(k,i) < l(k)
          x(k,i) = l(k);
      end
      %Eval�a cada part�cula modificada en la funci�n objetivo
      fx(i) = rosen(x(:,i));    
  end
end
