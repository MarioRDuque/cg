%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%EMO Est�ndar, propuesto por Birbil y Fang[1]
%Prueba con funci�n de Rosenbrock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Erik Cuevas, Valent�n Osuna-Enciso, Diego Oliva, Margarita D�az
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Limpia variables y cierra ventanas abiertas
close all
clear all
%L�mites del espacio de b�squeda
u =[10 10]; %L�mite superior
l = [-10 -10]; %L�mite inferior
%Par�metros de la poblaci�n EMO
%M�ximo de iteraciones
MAXITER = 100;
%Cantidad de part�culas en la poblaci�n
m = 30;
%Dimensiones del espacio de b�squeda
n = 2;
%EMO Original
%Generar la poblaci�n que ser� evolucionada durante la optimizaci�n
%Se generan m valores aleatorios
[x,fx] = incializa(m,n,u,l);
%Se obtiene el mejor valor de la funci�n objetivo para la poblaci�n
[fxbest,ind] = min(fx);%<- Minimiza
%Se asigna el valor del mejor elemento de la poblaci�n a la variable xbest
xbest = x(:,ind);
%Inicia el proceso de optimizaci�n EMO
%delta: Radio de b�squeda
delta = 0.65;
%LSITER: M�ximo de iteraciones para la b�squeda local para cada part�cula
LSITER = 20;
%Contador de iteraciones
it = 1;
while it <= MAXITER %Criterio de paro
  %B�squeda Local
  [x,fx,xbest,fxbest,ind] = localO(LSITER,delta,m,n,l,u,x,fx);    
  %C�lculo del vector de fuerza total
  F = calcFO(m,n,x,fx,xbest,fxbest);
  %Movimiento
  x = moveO(F,x,m,n,ind,l,u);
  %Se almacenan las mejores part�culas
  MejoresO(it) = fxbest;
  %Se incrementa en 1 el contador de iteraciones
  it = it + 1;
end
%Grafica la evoluci�n d la funci�n objetivo
figure
plot(MejoresO)
%Muestra en pantalla el valor optimo encontrado
disp(['Mejor posici�n x: ',num2str(xbest')])
disp(['Mejor valor funci�n objetivo: ',num2str(fxbest)])
