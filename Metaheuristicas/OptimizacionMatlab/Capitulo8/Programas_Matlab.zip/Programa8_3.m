%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%B�squeda Local, Algoritmo EMO Est�ndar, propuesto por Birbil y Fang [1]
%Prueba con funci�n de Rosenbrock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Erik Cuevas, Valent�n Osuna-Enciso, Diego Oliva, Margarita D�az
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x,fx,xbest,fxbest,ind]=localO(LSITER,delta,m,n,l,u,x,fx)
%Diferencia entre los limites
restas = u - l;
%Longitud del radio de b�squeda
longitud = delta * max(restas);
%Proceso de b�squeda local
for i=1:m 
  for k=1:n
        cont=1;
        %Se obtiene el primer valor aleatorio lambda1
        lambda1 = rand;
        while cont < LSITER
            %Se toma un elemento de la poblaci�n y se almacena en y
            y = x(:,i);
            %Se obtiene el segundo valor aleatorio lambda2
            lambda2 = rand;
            %Verifica la direcci�n de la b�squeda local con lambda1
            %Se modifica y en la dimensi�n k
            if lambda1 > 0.5
                y(k) = y(k) + lambda2 * longitud;
            else
                y(k) = y(k) - lambda2 * longitud;
            end
            %Se verifica que y no se salga del espacio de b�squeda
            if y(k) > u(k)
                y(k) = u(k); 
            elseif y(k) < l(k)
                y(k) = l(k); 
            end
            %Eval�a y en la funci�n objetivo
            fy = rosen(y); 
            
            %Se verifica si fy es mejor que fx(i)
            if fy < fx(i) %Minimiza
                %Si el valor de fy es mejor se actualiza la poblaci�n
                x(k,i) = y(k);
                fx(i) = fy;
                cont = LSITER-1;
            end
            cont = cont+1;
        end
    end      
end
%Se extrae la mejor particula de la poblaci�n
[fxbest,ind] = min(fx); %Minimiza
xbest = x(:,ind);
