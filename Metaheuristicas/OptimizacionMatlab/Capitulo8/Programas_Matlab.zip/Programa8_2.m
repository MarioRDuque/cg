%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Inicializaci�n, Algoritmo EMO Standar, propuesto por Birbil y Fang [1]
%Prueba con funci�n de Rosenbrock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Erik Cuevas, Valent�n Osuna-Enciso, Diego Oliva, Margarita D�az
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [x,fx] = incializa(m,n,u,l)
%Se genera las part�culas de forma aleatoria en el espacio de b�squeda
for i = 1:n
  %Se obtiene un numero aleatorio
  lambda = rand(1,m);
  x(i,:) = l(i) + lambda * (u(i) - l(i));
end
%Se eval�a cada part�cula en la funci�n objetivo (Rosenbrock)
for j = 1:m
  fx(j) = rosen(x(:,j));
end
