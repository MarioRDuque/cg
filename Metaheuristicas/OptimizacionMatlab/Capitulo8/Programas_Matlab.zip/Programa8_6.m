%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Funci�n de Rosenbrock
%Erik Cuevas, Valent�n Osuna-Enciso, Diego Oliva, Margarita D�az
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Funci�n que recibe un vector x n-dimensional
function fx = rosenbrock(x)
%N�mero de dimensiones 2 para este problema
n = 2;
sum = 0;
%Funci�n de Rosenbrock
for j = 1:n-1;
  sum = sum+100*(x(j)^2-x(j+1))^2+(x(j)-1)^2; 
end
%Regresa el valor de la funci�n objetivo
fx = sum;
