%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%C�lculo del vector de fuerza total, 
%Algoritmo EMO Est�ndar, propuesto por Birbil y Fang [1]
%Prueba con funci�n de Rosenbrock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Erik Cuevas, Valent�n Osuna-Enciso, Diego Oliva, Margarita D�az
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function F=calcF(m,n,x,fx,xbest,fxbest)
%C�lculo de la sumatoria de fx-fxbest de ecuaci�n 8.3
sumf=0;
for k=1:m
  sumf = sumf + (fx(k)-fxbest);
end
%C�lculo de las cargas ecuaci�n 8.3
F=zeros(n,m);
for i=1:m
  q(i)=exp(-n * ((fx(i) - fxbest)/sumf));
end
%C�lculo del vector de fuerzas ecuaci�n 8.4
for i=1:m
  for j=1:m
      for k = 1:n
          if fx(j) < fx(i)
             F(k,i)=F(k,i) + (x(k,j)-x(k,i)) * ((q(i)*q(j))/(distec(x(k,j),x(k,i))^2+eps));
          else
             F(k,i)=F(k,i) - (x(k,j)-x(k,i)) * ((q(i)*q(j))/(distec(x(k,j),x(k,i))^2+eps));
          end
      end
  end
end
