%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%HSA propuesto por Zong Woo Geem [1], [15]
%Prueba con funci�n de Rosenbrock
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Erik Cuevas, Valent�n Osuna-Enciso, Diego Oliva, Margarita D�az
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Limpiar pantalla y cerrar ventanas 
close all 
clear all
%Dimensiones del espacio de b�squeda
d = 2; 
%L�mites del espacio de b�squeda
%L�mite inferior
l = [-5, -5];
%L�mite superior
u = [10, 10];
%Inicializa par�metros de HSA
%Configuraci�n inicial
%Ancho de banda (BW)
BW = [100 100];
%Tama�o de la memoria de armon�as (HM)
HMS = 100;
%Par�metro de consideraci�n de la memoria (HM)
HMCR = 0.75;
%Par�metro de ajuste de tono
PAR = 0.5;
%M�ximo n�mero de iteraciones
NI = 1500;
%Inicializaci�n de la memoria de armon�as ecuaci�n 7.2
x = l(1) + rand(HMS,d).* (u(1) - l(1));
%Eval�a la funci�n objetivo
for i = 1:HMS
    fx(i,:) = rosen(x(i,:)); %Cap�tulo 4
end
%Genera la memoria de harmon�a HM ordenando fx y los elementos de x
[fxtemp,index] = sort(fx,'ascend'); %minimiza 
HM = x(index,:); %Memoria HM ecuaci�n 6.3
HMfx = fx(index); %Valores de la funci�n objetivo de HS 
% Inicia el algoritmo Harmony Search
for it = 1:NI,
  % Operadores de Harmony Search
  for j = 1:d
    %Usando el HCMR se decide si la nueva harmon�a es o no aleatoria ecuaci�n 6.4
    if (rand >= HMCR)
        %Se genera una nueva harmon�a aleatoria en j
        xHS(j) = l(j) + rand .* (u(j) - l(j));
    else
        %Se genera un nuevo valor para la dimensi�n j usando la HM
        xHS(j) = HM(fix(HMS * rand) + 1,j);
      %Usando PAR se decide si se ajusta j usando el BW ecuaci�n 6.5
      if (rand <= PAR)
          pa = (u(j) - l(j)) / BW(j);
          xHS(j) = xHS(j) + pa * (rand-0.5);
      end
    end
  end
  %Se verifica que las part�culas no se salgan de los limites u y l
  if xHS(1) > u(1)
      xHS(1) = u(1);
  elseif xHS(1) < l(1)
      xHS(1) = l(1);
  elseif xHS(2) > u(2)
      xHS(2) = u(2);
  elseif xHS(2) < l(2)
      xHS(2) = l(2);
  end
  %Se eval�a la nueva harmon�a en a funci�n objetivo
  fbest = rosen(xHS);
  %Se toma el peor elemento de la HM (ultimo)
  fHSpeor = HMfx(HMS);
  %Se compara la funci�n objetivo de la nueva harmon�a con la peor de HM
  if fbest < fHSpeor %minimiza  ->cambiar signo para maximizar<-
      %Si el valor de la nueva harmon�a es mejor, se actualiza HM
      HM(HMS, :) = xHS;
      HMfx(HMS) = fbest;
  end
  % Se ordena la HM de acuerdo a su valor de la funci�n objetivo
  [fxtemp,index] = sort(HMfx,'ascend'); %minimiza 
  HM = HM(index,:);
  %Eval�a HM en la funci�n objetivo
  for i = 1:HMS
    HMfx(i,:) = rosen(HM(i,:)); %Cap�tulo 4
  end
  %Almacena la mejor harmon�a actual 
  Evol_func_obj(it) = HMfx(1);
end
%Grafica la evoluci�n d la funci�n objetivo
plot(Evol_func_obj)
disp(['Mejor posici�n x: ',num2str(HM(1,:))])
disp(['Mejor valor funci�n objetivo: ',num2str(HMfx(1))])
