%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejemplo del algoritmo genetico con capacidad multimodal
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Erik Cuevas, Valent�n Osuna, Diego Oliva y Margarita D�az 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear all
global solnew sol pop popnew fitness fitold f range; 
%Funcion objetivo a optimizar
funstr='(2^(-2*(((x-0.1)/0.8)^2)))*(sin(5*pi*x)^6)';
%Se de fine el espacio de Busqueda
range=[0 1];      
f=vectorize(inline(funstr)); 
% Inicializacion de parametros
popsize=100;   %Tama�o de la poblacion N
MaxGen=30;     %Numero maximo de generaciones niter
nsite=3;       % Numero de mutaciones
pc=0.95;       %Probabilidad de cruzamiento
pm=0.05;       %Probabilidad de mutacion
nsbit=16;      %Longitud de la variable (bits)
%Se genera la poblacion inicial de N individuoa
popnew=init_genA(popsize,nsbit);
fitness=zeros(1,popsize);  % Se reserva memoria para el fitness   
%Se convierte la palabra binaria a decimal y se calcula la calidad 
 for i=1:popsize,
solnew(i)=bintodecA(popnew(i,:));
fitness(i)=f(solnew(i));
 end
%Inicia el proceso de optimizacion
 for i=1:MaxGen,
fitold=fitness; pop=popnew; sol=solnew;
%C�lculo de funci�n compartida      
ra = funcionCo(sol,1,0.1);
%Degradaci�n del fitness original 
Dfitness = Degradaf(fitold,ra); 
%Se genera una nueva poblacion M por seleccion probabilistica
%considerando como la calidad de los individuos, los valores de
%los fitness degradados Dfitness
     for z=1:popsize
     e=seleccionA(Dfitness);     
     MP(z,:)=pop(e,:);   
     end
%Se genera la nueva poblacion P(k+1)
for z1=1:2:popsize
%Se obtienen los individuos m1 y m2    
    p1=floor(popsize*rand)+1;
    p2=floor(popsize*rand)+1;
%Se aplica cruzamiento    
    if pc>rand,
%Se se aplica se obtiene c1 y c2        
   [NP(z1,:),NP(z1+1,:)]=crossoverA(MP(p1,:),MP(p2,:)) ;
    else
 %Si no permanecen m1 y m2  
        NP(z1,:)=MP(p1,:);
        NP(z1+1,:)=MP(p2,:);
    end
%Se aplica mutacion        
if pm>rand,
%Si se aplica se genera n1 y n2
mu1=NP(z1,:);
mu2=NP(z1+1,:);
NP(z1,:)=mutate(mu1,nsite); 
NP(z1+1,:)=mutate(mu2,nsite);     
end
end
%Se obtiene la solucion decimal y fitness
for i=1:popsize,
solnew(i)=bintodecA(NP(i,:));
fitness(i)=f(solnew(i));
 end
popnew=NP;
 end
%Se despliega como resultado final los N elementos de la poblacion final
 x=range(1):0.001:range(2); 
 plot(x,f(x));
 hold on
 plot(solnew,fitness,'or');
