function [Dfitness] = Degradaf(Fo,Ar)
%Se calcula el tama�o de la poblacion
in=length(Fo);
%Se degrada la calidad con respecto ala relacion de agrupamiento
for n=1:in
 Dfitness(n)=Fo(n)/Ar(n);   %Ecuacion 11.5
end

end

