function [ra] = funcionCo(Vs,alfa,sigma)
%Se obtiene el tama�o de la poblacion
in=length(Vs);
%Se c�lcula  funci�n compartida de todos los elementos
for s=1:in
    suma=0;
    for d=1:in
    %Se calcula la distancia entre individuos
    dis=abs(Vs(s)-Vs(d));
   %Se esta a una distancia sigma se calcula Co 
    if (dis<=sigma)
       Co=1-((dis/sigma)^alfa); 
    else
   %Si no no existe relacion entre los individuos
        Co=0;
    end
    ra(s)=Co+suma;
    suma=ra(s);
    end
end

