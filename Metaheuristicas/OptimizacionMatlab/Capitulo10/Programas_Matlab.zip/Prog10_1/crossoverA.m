 function [c,d]=crossoverA(a,b)
nn=length(a);
% Se generan 2 nuevos individuos
cpoint=floor(nn*rand)+1;
c=[a(1:cpoint) b(cpoint+1:end)];
d=[b(1:cpoint) a(cpoint+1:end)];
