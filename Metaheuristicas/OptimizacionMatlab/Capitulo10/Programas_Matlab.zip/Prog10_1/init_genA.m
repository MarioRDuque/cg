
function pop=init_genA(np,nsbit)
% Se generan np individuos de un ancho de nsbits
pop=rand(np,nsbit)>0.5;
