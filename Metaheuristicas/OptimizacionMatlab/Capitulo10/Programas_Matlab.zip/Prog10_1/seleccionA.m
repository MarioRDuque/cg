function [iE] = seleccionA(fP)
%Se obtiene el tama�o de la poblacion
Ps=length(fP);
%Se inicializa acumulador
suma=0;
%Se calcula la probabilidad de eleccion de un individuo P(k)
%y el acumulativo A(k)
for k=1:Ps
 P(k)=fP(k)/(sum(fP));
 suma=suma+P(k);
 A(k)=suma;
end
R=rand;
for u=1:Ps
    if (A(u)>=R)
      break  
    end
end
%El elelemento u es el seleccionado
iE=u;
end

