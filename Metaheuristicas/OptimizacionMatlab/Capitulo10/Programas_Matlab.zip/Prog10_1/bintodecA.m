 function [dec]=bintodecA(bin)
 global range;
% Se obtiene el tama�o de la cadena binaria
 nn=length(bin);
 num=bin;  % get the binary
%Se inicializa un acumulador
dec=0;
%Se determina segun el espacio de busqueda el valor representable
 dp=floor(log2(max(abs(range))));
 %Se convierte de binario a decimal
 for i=1:nn,
dec=dec+num(i)*2^(dp-i);
 end

