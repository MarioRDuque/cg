function evolveA(j)
global solnew popnew fitness fitold pop sol f;
solnew(j)=bintodecA(popnew(j,:));
% if (solnew(j)<0)
%    fitness(j)=-1;
% else
% fitness(j)=f(solnew(j));
% end
fitness(j)=f(solnew(j));
if fitness(j)>fitold(j), 
pop(j,:)=popnew(j,:);
 sol(j)=solnew(j);
fitold(j)=fitness(j); 
end
end