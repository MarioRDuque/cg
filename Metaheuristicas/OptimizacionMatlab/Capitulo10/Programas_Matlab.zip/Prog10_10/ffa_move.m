function [xn,yn]=ffa_move(xn,yn,Lightn,xo,yo,Lighto,alpha,gamma,range)
%Se obtiene el tama�o de la poblacion
ni=size(yn,2); 
%Se prueba cuales luciernegas seran atraidas
for i=1:ni, 
 for j=1:ni,
%Se calcula la distancia entre i j
r=sqrt((xn(i)-xo(j))^2+(yn(i)-yo(j))^2);
if Lightn(i)<Lighto(j),%Se prueba calidad 
   beta0=1;    beta=beta0*exp(-gamma*r.^2);
   %Se ejerce el movimiento Ecuacion 11.11
   xn(i)=xn(i).*(1-beta)+xo(j).*beta+alpha.*(rand-0.5);
   yn(i)=yn(i).*(1-beta)+yo(j).*beta+alpha.*(rand-0.5);
   end
end % end for j
end % end for i
%Si por los movimientos se salio del especio de busqueda se limita
[xn,yn]=findrange(xn,yn,range);