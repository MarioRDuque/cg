%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Ejemplo del algoritmo de las luciernegas
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Erik Cuevas, Valent�n Osuna, Diego Oliva y Margarita D�az 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Limpiar memoria
clear all
%Configura el numero de luciernagas y de iteraciones
n=250; MaxGeneration=100;
rand('state' ,0); %Se resetea el generador de numeros aleatorios
%Funcion objetivo a optimizar multimodal
funstr='(((sin(x-y))^2)*((sin(x+y))^2))/(sqrt(x^2+y^2))';
f=vectorize(inline(funstr)); 
%Se define el espacio de busqueda
range=[0 10 0 10];
%Se configura los parametros del algoritmo
alpha=0.006;     
gamma=4.0;     
%Se grafica inicialmente la funcion objetivo
Ndiv=100;
dx=(range(2)-range(1))/Ndiv; dy=(range(4)-range(3))/Ndiv;
[x,y]=meshgrid(range(1):dx:range(2),range(3):dy:range(4));
z=f(x,y);
figure(1);   surfc(x,y,z); figure(2);
%Se genera la poblacion inicial
[xn,yn,Lightn]=init_ffa(n,range);
%Inicia el proceso de optimizacion
for i=1:MaxGeneration,    % start iterations
%Se muestra el contorno de la funcion objetivo
contour(x,y,z,15); hold on;
%Se evalua la calidad de las soluciones
zn=f(xn,yn);
%Se asigna la intensidad de luz a las calidades
Lightn=zn;
xo=xn;  yo=yn;   Lighto=Lightn;
%Se despriega la distribucion de los elementos de la poblacion
plot(xn,yn,'o');

%plot(xn,yn,'.','markersize',10,'markerfacecolor','g');
%Se calcula la atraccion de acuerdo a Ecuacion 11.11
[xn,yn]=ffa_move(xn,yn,Lightn,xo,yo,Lighto,alpha,gamma,range);
drawnow; 
hold off;

if (i==98)
    p=1;
end

end  






