function f = FUNCION(x, d, N) 
f=[];
%Funcion de Schwefel, [-500,500], �ptimo: 0
% for i=1:N
%     sum=0;
%     for j = 1:d-1;
%         sum = sum+100*(x(i,j)^2-x(i,j+1))^2+(x(i,j)-1)^2;
%     end
%     f(i,1) = sum;
% end
% Rosenbrock, [-500,500], �ptimo: 0
% for i=1:N
%     s = sum(-x(i,:).*sin(sqrt(abs(x(i,:)))));
%     f(i,1) = 418.9829*d+s;
% end
% Schubert, [], �ptimo: -186.7309
for j=1:N
    s1 = 0; 
    s2 = 0;
    for i = 1:5   
        s1 = s1+i*cos((i+1)*x(j,1)+i);
        s2 = s2+i*cos((i+1)*x(j,2)+i);
    end
    f(j,1) = s1*s2;
end
