% Clonal Selection Algorithm, CUTONALA, Jos� Valent�n Osuna-Enciso, Julio,
% 2014.
function Fitness_best = CSA 
    %% PAR�METROS:
    Np = 100;       % Tama�o de la poblaci�n
    n = 90;         % N�mero de individuos a clonar
    d = 2;          % Dimensi�n del problema  
    Nb = 22;        % Bits por cada dimensi�n del individuo  
    maxIter = 40;   % N�mero m�ximo de iteraciones
    pm = 0.01;      % Probabilidad de mutaci�n
    Pd = 0.05;      %Porcentaje de diversidad
    Pc = 0.05;      % Porcentaje de clonaci�n
    pma = pm; 
    pmr = 0.8;      % 
    l = -10;u = 10; % L�mites del espacio de busqueda (Shubert)              
    k = 0;          % Iteraci�n actual
    nc = Np*Pc*n;   % N�mero total de clones en cada iteraci�n
    %% INICIALIZACI�N:
    B = 2 .* rand(Np,Nb*d) - 1;   
    B = hardlim(B);                  
    X=[];                         
    for i1 = 1 : Np
       X=[X;DECOD(B(i1,1:Nb),l,u,Nb),DECOD(B(i1,Nb+1:Nb*2),l,u,Nb)];
    end
    fx=FUNCION(X,d,Np);
    [fx,ind] = sort(fx);   % Np best individuals (minimization)
    %% ALGORITMO DE SELECCI�N CLONAL:
    while k <=  maxIter
        
        valx = X(ind(1:end),:); 
        %% CLONACI�N:
        [C,pcs] = CLONES(n,Pc,Np,ind,B);
        %% HIPERMUTACI�N:
        Cm=C;
        for i1=1:nc
            for i2=1:Nb*d
                if rand()<=pm
                    Cm(i1,i2)=~C(i1,i2);              
                end
            end
        end
        Cm(pcs,:) = B(ind(end-n+1:end),:);              
        Xm=[];                                
        for i1 = 1 : nc
            Xm=[Xm;DECOD(Cm(i1,1:Nb),l,u,Nb),DECOD(Cm(i1,Nb+1:Nb*2),l,u,Nb)];
        end
        fm = FUNCION(Xm,d,nc);      
        %% RESELECCI�N:
        pcs = [0 pcs];
        for i1=1:n
            [out(i1),bcs(i1)] = min(fm(pcs(i1)+1:pcs(i1+1)));  
            bcs(i1) = bcs(i1) + pcs(i1);
        end;
        B(ind(end-n+1:end),:) = Cm(bcs,:);
        X(ind(end-n+1:end),:)=Xm(bcs,:);
        fx(end-n+1:end,1)=out;
        [fx,ind] = sort(fx);
        %% INTRODUCCI�N DE DIVERSIDAD:   
        nd = round(Pd*Np); 
        B(ind(end-nd+1:end),:) = 2 .* rand(nd,Nb*d) - 1;   
        B(ind(end-nd+1:end),:) = hardlim(B(ind(end-nd+1:end),:)); 
        %% MUESTRA AVANCES EN PANTALLA:
        k = k + 1;
        pm = pmcont(pm,pma,pmr,k,maxIter); valfx(k) = min(fx);
        disp(sprintf('It.: %d  pm: %.4f  x: %2.2f  y: %2.2f f(x,y): %2.5f',k,pm,valx(1,:),valfx(k)));
    end; % end while
    x = valx(1,:); fx = min(fx);
    plot(valfx);
end
