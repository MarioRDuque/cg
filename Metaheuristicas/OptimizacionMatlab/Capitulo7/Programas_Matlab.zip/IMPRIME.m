%[x,y] = meshgrid(-15:0.8:30,-15:0.8:30); %Ackley
%[x,y] = meshgrid(0:0.1:pi,0:0.1:pi);    % Michalewics
[x,y] = meshgrid(-10:0.1:10,-10:0.1:10); % Schubert
z=[];
tam=size(x,1);
for ind=1:tam
   f = FUNCION([x(:,ind),y(:,ind)], 2, tam); 
   z=[z,f]; 
end
mesh(x,y,z)
%contour(x,y,z)